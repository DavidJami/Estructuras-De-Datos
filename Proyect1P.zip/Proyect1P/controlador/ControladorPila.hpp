#ifndef CONTROLADORPILA_HPP
#define CONTROLADORPILA_HPP
#include "../modelo/Pila.hpp"
#include "../vista/PilaVisual.hpp"
#include <string>


class ControladorPila {
private:
    Pila pila;
    PilaVisual pilaVisual;
    int contador = 1;

public:
    void manejarEventos(sf::RenderWindow& window);
    void dibujar(sf::RenderWindow& window);
};

#endif
