#include "ControladorPila.hpp"

void ControladorPila::manejarEventos(sf::RenderWindow& window) {
    sf::Event event;
    while (window.pollEvent(event)) {
        if (event.type == sf::Event::Closed)
            window.close();

        if (event.type == sf::Event::KeyPressed) {
            if (event.key.code == sf::Keyboard::A) {
                std::string valor = "N" + std::to_string(contador++);
                pila.push(valor);
                pilaVisual.push(valor);
            }
            if (event.key.code == sf::Keyboard::D) {
                pila.pop();
                pilaVisual.pop();
            }
        }
    }
}

void ControladorPila::dibujar(sf::RenderWindow& window) {
    pilaVisual.dibujar(window);
}
