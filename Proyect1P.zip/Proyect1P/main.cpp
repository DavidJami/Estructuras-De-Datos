#include <SFML/Graphics.hpp>
#include "controlador/ControladorPila.hpp"

int main() {
    sf::RenderWindow window(sf::VideoMode(800, 600), "Visualizador de Pila Dinamica");
    window.setFramerateLimit(60);

    ControladorPila controlador;

    while (window.isOpen()) {
        controlador.manejarEventos(window);

        window.clear(sf::Color::Black);
        controlador.dibujar(window);
        window.display();
    }

    return 0;
}
