#include "PilaVisual.hpp"

PilaVisual::PilaVisual() {
   if (!fuente.openFromFile("C:/Windows/Fonts/consola.ttf")) {
    std::cerr << "No se pudo cargar la fuente.\n";
}

}

void PilaVisual::push(const std::string& dato) {
    NodoVisual nuevo(dato, fuente, origenX);
    nuevo.yDestino = baseY - nodos.size() * (alto + 10);
    nodos.push_back(nuevo);
}

void PilaVisual::pop() {
    if (!nodos.empty()) {
        nodos.pop_back();
    }
}

void PilaVisual::dibujar(sf::RenderWindow& window) {
    for (auto& nodo : nodos) {
        sf::Vector2f pos = nodo.rect.getPosition();
        if (pos.y < nodo.yDestino) {
            nodo.rect.move(sf::Vector2f(0.f, 5.f));
            nodo.label.move(sf::Vector2f(0.f, 5.f));
        }
        window.draw(nodo.rect);
        window.draw(nodo.label);
    }
}


