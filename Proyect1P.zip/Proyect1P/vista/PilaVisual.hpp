#ifndef PILAVISUAL_HPP
#define PILAVISUAL_HPP

#include <SFML/Graphics.hpp>
#include <vector>
#include <string>

struct NodoVisual {
    std::string texto;
    sf::RectangleShape rect;
    sf::Text label = sf::Text("temp", sf::Font(), 18);
    float yDestino;

    NodoVisual(const std::string& t, const sf::Font& fuente, float posX)
        : texto(t), rect(), label(sf::Text()), yDestino(0.0f)
    {
        rect.setSize(sf::Vector2f(120.f, 40.f));
        rect.setFillColor(sf::Color::Blue);
        rect.setPosition(sf::Vector2f(posX, 0.f));

        label.setFont(fuente);
        label.setString(t);
        label.setCharacterSize(18);
        label.setFillColor(sf::Color::White);
        label.setPosition(sf::Vector2f(posX + 10.f, 0.f));
    }
};

class PilaVisual {
private:
    std::vector<NodoVisual> nodos;
    sf::Font fuente;
    const int ancho = 120, alto = 40, origenX = 350, baseY = 500;

public:
    PilaVisual();
    void push(const std::string& dato);
    void pop();
    void dibujar(sf::RenderWindow& window);
};

#endif
