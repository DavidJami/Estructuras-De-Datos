#ifndef PILA_HPP
#define PILA_HPP
#include "Nodo.hpp"
#include <string>


class Pila {
private:
    Nodo* cima;
    int tam;

public:
    Pila();
    ~Pila();

    void push(const std::string& valor);
    void pop();
    std::string top() const;
    bool vacia() const;
    int size() const;
};

#endif

