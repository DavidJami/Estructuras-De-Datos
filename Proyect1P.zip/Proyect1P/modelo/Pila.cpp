#include "Pila.hpp"

Pila::Pila() : cima(nullptr), tam(0) {}

Pila::~Pila() {
    while (!vacia()) pop();
}

void Pila::push(const std::string& valor) {
    Nodo* nuevo = new Nodo(valor);
    nuevo->siguiente = cima;
    cima = nuevo;
    tam++;
}

void Pila::pop() {
    if (!vacia()) {
        Nodo* temp = cima;
        cima = cima->siguiente;
        delete temp;
        tam--;
    }
}

std::string Pila::top() const {
    return cima ? cima->dato : "";
}

bool Pila::vacia() const {
    return cima == nullptr;
}

int Pila::size() const {
    return tam;
}
