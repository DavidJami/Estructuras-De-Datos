#ifndef NODO_HPP
#define NODO_HPP
#include <string>


struct Nodo {
    std::string dato;
    Nodo* siguiente;

    Nodo(const std::string& d) : dato(d), siguiente(nullptr) {}
};

#endif
